#!/usr/bin/env python3
import numpy as np
import re
import pandas as pd 
import sys
import os
def main():

	#Identifies the relevant files
	ipmsBase=os.environ["IPMS_DIR"]
	batchName="20230706_AbVal_8MUrea_pilot"
	inFile="20230706_AbVal_8MUrea_pilot_DDA_medianNorm_noImp_NA_psdct1_log2.txt"
 
 
	#Reads the column names
	with open("%s/rawData/%s/%s"%(ipmsBase, batchName, inFile)) as f:
		l = f.readline()
	d=l.rstrip().split('\t')
	
	#Determines the full set of factors in each experiment
	factorSets  = {}
	nMeasure    = {}
	headerToCol = {}
	for iC in range(len(d)):
		di = d[iC]
		if re.match("^M[0-9]+_", di) or re.match("^Mix[0-9]+_", di):

			if re.match("^M[0-9]+_", di):
				iStart = 2
				expKey = dii[1]
			else:
				iStart = 1
				expKey = "8MUrea"

			dii = di.replace("G2BP2","G3BP2").replace("G3PC2","G3BP2").split("_")
			if expKey not in factorSets:
				factorSets[expKey] = set()
				nMeasure[expKey]   = 0
			nMeasure[expKey] += 1


			for i in range(iStart,len(dii),2):
				factorSets[expKey].add(dii[i])
			headerToCol[di] = iC

	#Creates ordered lists of factors	
	factorOrder = {}
	factorToCol = {}
	for expKey in factorSets:
		temp = list(sorted(factorSets[expKey]))
		factorOrder[expKey] = temp
		factorToCol[expKey] = dict([ (temp[i],i) for i in range(len(temp))])

	#Creates the design matrices
	designMatrices = {}
	iRow           = {}
	rowNames       = {}
	for iC in  range(len(d)):
		di = d[iC].replace("G2BP2","G3BP2").replace("G3PC2","G3BP2")
		if re.match("^M[0-9]+_", di) or re.match("^Mix[0-9]+_", di):

			if re.match("^M[0-9]+_", di):
				iStart = 2
				expKey = dii[1]
			else:
				iStart = 1
				expKey = "8MUrea"

			dii    = di.split("_")
		
			if expKey not in designMatrices:
				designMatrices[expKey] = np.zeros((nMeasure[expKey], len(factorOrder[expKey])))
				iRow[expKey] = 0
				rowNames[expKey] = []


				
			for i in range(iStart,len(dii),2):
				designMatrices[expKey][iRow[expKey],factorToCol[expKey][dii[i]]] = float(dii[i+1])

			rowNames[expKey] += [d[iC]]
			iRow[expKey] += 1


	annotations = {
		"AATF" : 	"Q9NY61",
		"DDX42": 	"Q86XP3",
		"DLD":		"P09622",
		"EPRS":		"P07814",
		"G3BP2":	"Q9UN86",
		"KARS":		"Q15046",
		"MCM2":		"P49736",
		"NOLC1":	"S4R341",
		"NUP35":	"Q8NFH5",
		"PRPF8":	"Q6P2Q9",
		"RBFOX2":	"A0A0G2JRA5;B0QYV1;B0QYY4;O43251;S4R469",
		"RPS5":		"M0R0F0;P46782",
		"RUVBL2":	"Q9Y230",
		"YTHDC1":	"Q96MU7",
		"YTHDF1":	"Q9BYJ9"
	}
	for expKey in designMatrices:
		orderedRows = [""] * len(rowNames[expKey])
		rowReordering = [None] * len(rowNames[expKey])
		for i in range(len(rowNames[expKey])):
			iPool = int(rowNames[expKey][i].split("_")[0].lstrip("Mix"))
			orderedRows[iPool-1] = rowNames[expKey][i]
			rowReordering[iPool-1] = i
		
		cn = [ "%s"%(factor) for factor in factorOrder[expKey]]
		#rn =  [ "%d:%s"%(headerToCol[rn],rn)for rn in rowNames[expKey]]
		#rn =  [ "%d:%s"%(headerToCol[rn],rn)for rn in orderedRows ]
		outDF = pd.DataFrame(designMatrices[expKey][rowReordering], ["Pool.%d"%(i+1) for i in range(len(orderedRows))])
		with open("%s/standardizedData/%s/%s.mixingMatrix.tsv"%(ipmsBase, batchName, batchName), 'w') as f:
			f.write("\t%s\n"%("\t".join(cn)))
			f.write("\t%s\n"%("\t".join([annotations[f] for f in cn])))
			outDF.to_csv(f, sep='\t', header=None)
		#outDF.to_csv("%s/standardizedData/%s/%s.mixingMatrix.tsv"%(ipmsBase, batchName, batchName), sep='\t')
	
	
main()

