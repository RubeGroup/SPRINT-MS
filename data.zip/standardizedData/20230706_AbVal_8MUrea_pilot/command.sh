#!/bin/bash
#NOTE: Code needed for building these intensities

cat ../../rawData/20230706_AbVal_8MUrea_pilot/20230706_AbVal_8MUrea_pilot_DDA_medianNorm_noImp_NA_psdct1_log2.txt  | sed 's@\r@@'  | awk '{if(NR==1){printf "\tGene Names\tProtein IDs\t";for(i=3;i<=NF;i++){printf "Intensity "(i-2)"\t"; split($i,a,"_");s[substr(a[1],4)+2]=i};print ""} else {printf NR-2"\t"$2"\t"$1"\t"; for(i=3;i<=NF;i++){printf $(s[i])"\t"};print ""}}'  > 20230706_AbVal_8MUrea_pilot.intensity.tsv

