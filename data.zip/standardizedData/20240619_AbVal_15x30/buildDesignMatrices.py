#!/usr/bin/env python3
import numpy as np
import re
import pandas as pd 
import sys
import os
def main():

	#Identifies the relevant files
	ipmsBase=os.environ["IPMS_DIR"]
	batchName="20240619_AbVal_15x30"
	inFile="20240620_30x15_Pilot.mixingMatrix.tsv"
 
	annotations = {
		"PSMA3":"P25788",
		"DLST":"P36957",
		"MCM2":"P49736",
		"SMG1":"Q96Q15",
		"ARP3":"P61158",
		"V5":"",
		"CPSF30":"O95639",
		"CCT2":"P78371",
		"COG3":"Q96JB2",
		"EXOSC10":"Q01780",
		"SMARCC1":"Q92922",
		"RPL23":"P62829",
		"DCTN1":"Q14203",
		"RUVBL2":"Q9Y230",
		"EIF3A":"Q14152",
		"RANBP9":"Q96S59",
		"SEPTIN2":"B5MCX3",
		"APC2":"Q9UJX6",
		"COPB1":"P53618",
		"Prefoldin1":"O60925",
		"RPL23A":"P62750",
		"EXOSC2":"Q13868",
		"COPS5":"Q92905",
		"DLD":"P09622",
		"PSF1":"Q14691",
		"PPP2CA/B C subunit":"P67775",
		"DYNC1H1":"Q14204",
		"FUS":"P35637",
		"CSTF64":"P33240",
		"IgG":""
	}
	mixingMatrix = pd.read_csv("%s/rawData/%s/%s"%(ipmsBase, batchName, inFile), sep='\t').drop("Unnamed: 0", axis=1)
	cols=list(mixingMatrix.columns)
	mixingMatrix["Pool"] = ["Pool.%d"%(i+1) for i in range(15) ]

	for expName in ["20240619_AbVal_15x30_IP", "20240619_AbVal_15x30_Urea"]:
		with open("%s/standardizedData/%s/%s.mixingMatrix.tsv"%(ipmsBase, batchName, expName), 'w') as f:
			f.write("\t%s\n"%("\t".join(cols[1:])))
			f.write("\t%s\n"%("\t".join([annotations[c] for c in cols[1:]])))
			mixingMatrix.to_csv(f, sep='\t', header=False, index=False)
	
	
main()

