#!/bin/bash
expName="20240619_AbVal_15x30_IP";   fIn="${expName}_DDA_MQ_LFQ_iBAQ_matchBwRuns_proteinGroups.txt"; python3 build.py ../../rawData/20240619_AbVal_15x30/$fIn --json config.IP.json   --key intensity --output ${expName}.intensity.tsv
expName="20240619_AbVal_15x30_IP";   fIn="${expName}_DDA_MQ_LFQ_iBAQ_matchBwRuns_proteinGroups.txt"; python3 build.py ../../rawData/20240619_AbVal_15x30/$fIn --json config.IP.json   --key lfq       --output ${expName}.lfq.tsv
expName="20240619_AbVal_15x30_Urea"; fIn="${expName}_DDA_MQ_LFQ_iBAQ_matchBwRuns_proteinGroups.txt"; python3 build.py ../../rawData/20240619_AbVal_15x30/$fIn --json config.Urea.json --key intensity --output ${expName}.intensity.tsv
expName="20240619_AbVal_15x30_Urea"; fIn="${expName}_DDA_MQ_LFQ_iBAQ_matchBwRuns_proteinGroups.txt"; python3 build.py ../../rawData/20240619_AbVal_15x30/$fIn --json config.Urea.json --key lfq       --output ${expName}.lfq.tsv
