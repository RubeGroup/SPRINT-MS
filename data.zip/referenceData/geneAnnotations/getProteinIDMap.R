#Loads the UniProt.ws interface
if (!requireNamespace("BiocManager", quietly = TRUE))
  install.packages("BiocManager")

BiocManager::install("UniProt.ws")

library(UniProt.ws)

#Functions for listing all keys and values
#keytypes(up)
#columns(up)

#Sets the tax_id to yeast
up <- UniProt.ws(taxId=4932)
species(up)

#Reads a list containing all IDs 
yeastGenes=read.csv("/Users/rube/UCM/Projects/2025-04 - Pooled IP-MS/IPMS-Package/PooledIPMS/referenceData/geneAnnotations/yeastID.SGD.tsv",  sep="\t")

#Writes the table to file:
write.table(protein_info, "/Users/rube/UCM/Projects/2025-04 - Pooled IP-MS/IPMS-Package/PooledIPMS/referenceData/geneAnnotations/SGD.yeastID.uniProt.tsv", sep="\t", quote=FALSE, row.names=FALSE)
